/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Ghost
 */
public class contact extends HttpServlet {

  
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        String ccusto,eemail,subj,msg;
       
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();                   
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection conn=DriverManager.getConnection("jdbc:ucanaccess://G:/preorder.accdb");            
            ccusto=request.getParameter("custoname");
            eemail=request.getParameter("email");
            subj=request.getParameter("subject");
            msg=request.getParameter("message");
           
        //    s.executeUpdate("INSERT into 'Employee' ('ST_ID','STU_ID','ST_NAME','CLASS','ADDRESS','DOB','English','Language','Maths','Science','Social','Total','Rank','Attendance') VALUES('"+stfid+"','"+stid+"','"+stname+"','"+stclass+"','"+staddr+"','"+stdob+"','"+steng+"','"+stlan+"','"+stmat+"','"+stsci+"','"+stsoc+"','"+sttot+"','"+strank+"','"+statt+"')");
            PreparedStatement p=conn.prepareStatement("INSERT into [contactus] ([custoname],[email],[subject],[message]) VALUES(?,?,?,?)");
            p.setString(1,ccusto);
            p.setString(2,eemail);
            p.setString(3,subj);
            p.setString(4,msg);
            p.executeUpdate();
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Thank u for your feedback!');");
            out.println("location='index.jsp';");
            out.println("</script>");  
            
          //  request.getRequestDispatcher("add_stu").forward(request, response);
            }
            catch(ClassNotFoundException | SQLException e)
            {
            }
        
    }


    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
