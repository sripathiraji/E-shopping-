/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
/**
 *
 * @author iamsr
 */
@WebServlet(urlPatterns = {"/login"})
public class login extends HttpServlet {
    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
       
       String a,b;
       a = request.getParameter("username");
       b = request.getParameter("password");
       out.println(a);
       out.println(b);
        try{
          // Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
           Connection conn=DriverManager.getConnection("jdbc:ucanaccess://G:/preorder.accdb");
           Statement s=conn.createStatement();
             
           ResultSet rs= s.executeQuery("SELECT [username],[password] FROM [custologin] WHERE username='"+a+"' and password='"+b+"'");
            if(rs.next())
           {
               out.println("alert('Correct Password');");
               request.getRequestDispatcher("product.jsp").forward(request, response);
           }
             else
           {
               out.println("<script type=\"text/javascript\">");
               out.println("alert('Wrong username or password');");
               out.println("location='llogin.jsp';");
               out.println("</script>");
           }
            
         }
        catch(Exception e)
       {
           
       }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
 
    }
