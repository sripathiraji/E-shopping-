/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Ghost
 */
public class register extends HttpServlet {

  
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        //String stfid;
        String ccusto,eemail,aaddr,pphno,uuser,ppass,ggen;
       // int id;
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter(); 
    try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection conn=DriverManager.getConnection("jdbc:ucanaccess://G:/preorder.accdb");

            //stfid= Integer.toString(id);
            
            ccusto=request.getParameter("custoname");
            eemail=request.getParameter("emailid");
            aaddr=request.getParameter("addr");
            pphno=request.getParameter("phno");
            ggen=request.getParameter("gender");
            uuser=request.getParameter("username");
            ppass=request.getParameter("password");
            
          //    s.executeUpdate("INSERT into 'Employee' ('ST_ID','STU_ID','ST_NAME','CLASS','ADDRESS','DOB','English','Language','Maths','Science','Social','Total','Rank','Attendance') VALUES('"+stfid+"','"+stid+"','"+stname+"','"+stclass+"','"+staddr+"','"+stdob+"','"+steng+"','"+stlan+"','"+stmat+"','"+stsci+"','"+stsoc+"','"+sttot+"','"+strank+"','"+statt+"')");
            PreparedStatement p=conn.prepareStatement("INSERT into [register] ([custoname],[emailid],[addr],[phno],[gender],[username],[password]) VALUES(?,?,?,?,?,?,?)");
            p.setString(1, ccusto);
            p.setString(2, eemail);
            p.setString(3,aaddr);
            p.setString(4,pphno);
            p.setString(5,ggen);
            p.setString(6,uuser);
            p.setString(7,ppass);
            p.executeUpdate();
            
            PreparedStatement q=conn.prepareStatement("INSERT into [custologin] ([username],[password],[Product]) VALUES(?,?,NULL)");
             q.setString(1,uuser);
            q.setString(2,ppass);
            q.executeUpdate();
            out.println("<script type=\"text/javascript\">");
            out.println("alert('YOUR DETAILS ARE REGISTERED');");
            out.println("location='regsuccess.jsp';");
            out.println("</script>");  
           
            }
            catch(ClassNotFoundException | SQLException e)
            {
            }
        
    }


    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
